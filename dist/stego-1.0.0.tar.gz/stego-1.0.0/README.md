# Steganography
Steganography is the art of hiding messages in (images, videos or even audio)

# Prerequisites
It uses the `PIL`, `numpy` and `cryptography` modules

run `pip install -r requirements-stego.txt` to download all the libraries

# How to use
run `python stego.py --help`

# Todo
- [ ] Code Refractor
- [ ] Write better tests
- [ ] Rework RSA
- [ ] Other formats Video/Audio
- [ ] Finish Packaging
